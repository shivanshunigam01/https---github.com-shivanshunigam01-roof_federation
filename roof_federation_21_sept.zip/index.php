<?php include "header.php"; ?>
<style>
.feature-one {
    position: relative;
    display: block;
    padding: 20px 0 40px;
}
.pdbnd{
        padding-bottom: 0px;
}
.es-header-btn{
        background-color: green !important;
}
.pdtp0q{
    padding-top: 0px;
}
.sk_branding a{
    display:none !important;
}
.sghdq .feature-one__single{
    padding:10px !important;
    height:auto !important;
}
.sghdq .feature-one__top-title-box{
    margin:0;
}
.regnd{
        font-size: 18px;
    padding-top: 20px;
    font-weight: bold;
}
.sk-ig-bottom-btn-container{
    margin-top:20px !important;
}
.feature-two__single-inner {
    position: relative;
    display: block;
    background-color: var(--oxpins-black);
    padding: 47px 50px 45px;
    border-radius: var(--oxpins-bdr-radius);
    overflow: hidden;
    z-index: 1;
    height: 220px;
}
.gallery-page__img img {
    width: 100%;
    border-radius: var(--oxpins-bdr-radius);
    height: 300px;
    width: 100%;
    object-fit: cover;
}

.swiper-wrapper{
    height:600px;
}


.instagram-user-container{
    background-color: #fbd45a !important;
    border-color: #fbd45a !important;
    color: rgb(51, 51, 51) !important;
    font-weight: bold !important;
        padding: 7px 35px !important;
            width: 150px !important;
            border-radius:30px !important;
}
.sk-ig-load-more-posts{
    background-color: #fbd45a !important;
        width: 150px !important;
    border-color: #fbd45a !important;
    color: rgb(51, 51, 51) !important;
    font-weight: bold !important;
    border-radius:30px !important;
}

.es-header-btn { 
    background-color: #fbd45a !important; 
    color: #000 !important;
}
.es-header-btn, .es-header-btn:active, .es-header-btn:focus{
    background-color: #fbd45a !important; 
    color: #000 !important;
}

.embedsocial-hashtag .es-widget-header-image{
    display:none !important;
}
</style>
        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->

        <!--Main Slider Start-->
        <section class="main-slider clearfix">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": 5000
                }}'>
                <div class="swiper-wrapper">
 
                    <div class="swiper-slide">
                        <div class="image-layer"
                            style="background-image: url(https://rooffederation.com/png_logo.png);"></div>
                        <!-- /.image-layer -->

                        <div class="main-slider-shape-1"
                            style="background-image: url(assets/images/shapes/main-slider-shape-1.jpg);"></div>
                        

                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6 col-lg-8">
                                    <div class="main-slider__content" style="position: relative;
    bottom: 100px;">
                                        <h2 class="main-slider__title ftalgeria mobhide" style="color:#fff;white-space:nowrap;font-size:65px;">ROOF FEDERATION</h2>
                                        <h2 class="main-slider__title ftalgeria deskhide" style="color:red;white-space:nowrap;"><img src="uploads/dwde.png" style="width:300px;"></h2>
                                        <p class="main-slider__sub-title" style="margin-bottom:20px;">Time to repair the sky</p>
                                        <p class="main-slider__sub-title" style="padding-bottom:20px;color:#fff;font-size:25px;">We Helping People By Providing Food, Education, Medicines, And Clothes, And Our Future Goals Are To Give Them A Roof For Living.</p>
                                        <div class="main-slider__btn-box">
                                            <a href="https://rooffederation.com/about-us" class="thm-btn main-slider__btn"> About Us</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="image-layer"
                            style="background-image: url(assets/images/backgrounds/main-slider-1-2.png);"></div>
                        <!-- /.image-layer -->

                        <div class="main-slider-shape-1"
                            style="background-image: url(assets/images/shapes/main-slider-shape-1.jpg);"></div>
                        <div class="main-slider-shape-2 float-bob-x">
                            <img src="assets/images/shapes/main-slider-shape-2.png" alt="">
                        </div>

                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6 col-lg-8">
                                    <div class="main-slider__content">
                                        <p class="main-slider__sub-title">Lend a Helping Hand to Those in Need</p>
                                        <h2 class="main-slider__title" style="font-size:50px;">We Need Your Support to FEED THE NEEDY</h2>
                                           <div class="main-slider__btn-box">
                                            <a href="https://rooffederation.com/contact-us" class="thm-btn main-slider__btn"> Contact Us</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
 

                </div>

                <!-- If we need navigation buttons -->
                <div class="main-slider__nav">
                    <div class="swiper-button-prev" id="main-slider__swiper-button-next">
                        <i class="icon-left-arrow"></i>
                    </div>
                    <div class="swiper-button-next" id="main-slider__swiper-button-prev">
                        <i class="icon-right-arrow"></i>
                    </div>
                </div>

            </div>
        </section>
        <!--Main Slider End-->

        <!--About One Start-->
        <section class="about-one">
            <div class="about-one__shape-box-1">
                <div class="about-one__shape-1"
                    style="background-image: url(assets/images/shapes/about-one-shape-1.png);"></div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="about-one__left">
                            <div class="about-one__img-box wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <div class="about-one__img">
                                    <img src="assets/images/resources/about-one-img-1.jpg" alt="">
                                </div>
                                <div class="about-one__img-border"></div>
                                <div class="about-one__curved-circle-box">
                                    <div class="curved-circle">
                                        
                                    </div><!-- /.curved-circle -->
                                    <div class="about-one__curved-circle-icon">
                                        <img src="https://rooffederation.com/uploads/logo.png" class="roof_logos" alt="">
                                    </div>
                                </div>
                                <div class="about-one__shape-2 zoom-fade">
                                    <img src="assets/images/shapes/about-one-shape-2.png" alt="">
                                </div>
                                <div class="about-one__shape-3 float-bob-y">
                                    <img src="assets/images/shapes/about-one-shape-3.png" alt="">
                                </div>
                                <div class="about-one__shape-4 zoominout">
                                    <img src="assets/images/shapes/about-one-shape-4.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="about-one__right">
                            <div class="section-title text-left">
                                <span class="section-title__tagline">Welcome to Roof Federation</span>
                                <h2 class="section-title__title">Helping each other can make world better</h2>
                            </div>
                            <p class="about-one__text">When people come together to support each other, they build strong and vibrant communities. By sharing resources, skills, and knowledge, they can create a more resilient and sustainable society. </p><br>
                             <p>Roof Federation was founded in the year 2022 by a young social entrepreneur who further brought a group of like minded people together to contribute towards the betterment of society with focus on child education, holistic child development and women empowerment. We started this journey with a dream of creating a world where every child is showered with love, given opportunities for having a bright future, no child’s innocence is marred by the horrors of child labour, and a world where women’s well being is paid attention to and they’re empowered to sustain themselves and their family.</p>
                             <p class="regnd">Reg.No - 726/2022-2023/4</p>
                             
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--About One End-->
        
        <section class="donations-list">
            <div class="container">
                <div class="donations-list__inner">
                    <!--Donations List Single Start-->
                    <div class="donations-list__single">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6">
                                <div class="donations-list__img">
                                    <img src="https://rooffederation.com/uploads/img-4.webp" alt="">
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="donations-list__right">
                                    <div class="donations-list__content">
                                        <div class="donations-list__category">
                                            <p>Vision</p>
                                        </div>
                                        <h3 class="donations-list__title"><a href="javascript:void(0);">Our Vision</a></h3>
                                        <p class="donations-list__text">To make human settlements equitable living environments where all residents and vulnerable people have access to health, education, essential infrastructure services and livelihood options, irrespective of their economic and social status.</p>
                                        <p class="donations-list__text pdtop5">We firmly believe that every child deserves the best chance for a bright future, which is why, we are fiercely committed to ensure that children not only survive, but thrive. With a bold ambition and a powerful vigilance, we do whatever it takes to save the children.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Donations List Single End-->
                     
                     <div class="donations-list__single">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6">
                                <div class="donations-list__right">
                                    <div class="donations-list__content">
                                        <div class="donations-list__category">
                                            <p>Mission</p>
                                        </div>
                                        <h3 class="donations-list__title"><a href="javascript:void(0);">Our Mission</a></h3>
                                        <p class="donations-list__text">Our hope is inspired by our faith and the strength and resourcefulness of our brothers and sisters whom we serve, and we rely on the natural resources of our land. We ardently believe that by working together, we can have a better world.</p>
                                        <p class="donations-list__text pdtop5">To inspire breakthroughs in the way the world treats children, and to achieve immediate, and lasting change in their lives</p>
                                        <p class="donations-list__text pdtop5">To efficiently and effectively regulate and enable the charitable sector to enhance its role in National development.</p>
                                         
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="donations-list__img">
                                    <img src="https://rooffederation.com/uploads/img-5.webp" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
         <!--Counter One Start-->
        <section class="counter-one">
            <div class="container">
                <div class="counter-one__inner">
                    <div class="counter-one-bg" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                        style="background-image: url(assets/images/backgrounds/counter-one-bg.jpg);"></div>
                    <ul class="list-unstyled counter-one__list">
                        <li class="counter-one__single">
                            <div class="counter-one__count-box">
                                <h3 class="odometer" data-count="21000">00</h3>
                                <span class="counter-one__letter">+</span>
                            </div>
                            <p class="counter-one__text">Road Safety</p>
                        </li>
                        <li class="counter-one__single">
                            <div class="counter-one__count-box">
                                <h3 class="odometer" data-count="25000">00</h3>
                                <span class="counter-one__letter">+</span>
                            </div>
                            <p class="counter-one__text">Tree Plantation</p>
                        </li>
                        <li class="counter-one__single">
                            <div class="counter-one__count-box">
                                <h3 class="odometer" data-count="5000">00</h3>
                                <span class="counter-one__letter">+</span>
                            </div>
                            <p class="counter-one__text">Women Empowerment</p>
                        </li>
                        <li class="counter-one__single">
                            <div class="counter-one__count-box">
                                <h3 class="odometer" data-count="2700">00</h3>
                                <span class="counter-one__letter">+</span>
                            </div>
                            <p class="counter-one__text">Child Education</p>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!--Counter One End-->
        <section class="feature-one">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6  wow slideInLeft animated" data-wow-delay="100ms" data-wow-duration="2500ms" style="visibility: visible; animation-duration: 2500ms; animation-delay: 100ms; animation-name: slideInLeft;">
                        <div class="feature-one__single">
                            <div class="feature-one__single-bg" style="background-image: url(assets/images/shapes/feature-one-shape-1.png);"></div>
                            <div class="feature-one__top">
                                <div class="feature-one__top-inner">
                                    <div class="feature-one__top-icon">
                                        <span class="icon-help"></span>
                                    </div>
                                    <div class="feature-one__top-title-box">
                                        <h3 class="feature-one__top-title"><a href="https://rooffederation.com/become-a-volunteer/">Join us &amp;
                                                become <br> a
                                                volunteer</a></h3>
                                    </div>
                                </div>
                            </div>
                            <p class="feature-one__text">Becoming a volunteer content creator can be a great way to give back to your community Here are some steps you can take to become a volunteer content creator:</p>
                            <ul class="list-unstyled feature-one__point">
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Reach out: Reach out to the organizations and express your interest in volunteering. Explain your skills, experience, and availability.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Collaborate and communicate: Collaborate and communicate with the organization's team to ensure that your content is meeting their needs.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Keep learning: Keep learning and updating your skills to enhance your content creation abilities.</p>
                                    </div>
                                </li>
                            </ul> 
                            <a href="https://rooffederation.com/become-a-volunteer/" class="thm-btn feature-one__btn">Join us</a>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6  wow slideInRight animated" data-wow-delay="100ms" data-wow-duration="2500ms" style="visibility: visible; animation-duration: 2500ms; animation-delay: 100ms; animation-name: slideInRight;">
                        <div class="feature-one__single feature-one__single--two">
                            <div class="feature-one__single-bg" style="background-image: url(assets/images/shapes/feature-one-shape-1.png);"></div>
                            <div class="feature-one__top">
                                <div class="feature-one__top-inner">
                                    <div class="feature-one__top-icon feature-one__top-icon--two">
                                        <span class="icon-gift-box"></span>
                                    </div>
                                    <div class="feature-one__top-title-box">
                                        <h3 class="feature-one__top-title"><a href="https://rooffederation.com/donate/">Send
                                                a gift for <br>
                                                childrens</a></h3>
                                    </div>
                                </div>
                            </div>
                            <p class="feature-one__text">We can suggest some gift ideas for children's content that you can consider</p>
                            <ul class="list-unstyled feature-one__point">
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Children's books: Books are always a great gift for children. You can choose from a variety of options, including picture books, chapter books, and non-fiction books on topics that interest them.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Art supplies such as coloring books, markers, crayons, and paint sets can encourage children to be creative and express themselves through art.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Educational games and puzzles: Games and puzzles are a fun and interactive way for children to learn new skills and concepts.</p>
                                    </div>
                                </li>
                            </ul> 
                            <a href="https://rooffederation.com/donate/" class="thm-btn feature-one__btn">Send Gift</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Causes One Start-->
        <section class="causes-one pdbnd">
            <div class="container">
                <div class="section-title text-center">
                    <span class="section-title__tagline">Encircling the vision of making the world a better place to live.</span>
                    <h2 class="section-title__title">Our Services</h2>
                </div>
                <div class="row">
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms" onclick="location.href='https://rooffederation.com/child-friendly-spaces'">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="https://rooffederation.com/uploads/childd.jpeg" alt="">
                                <div class="causes-one__cat">
                                    <p>Education</p>
                                </div>
                            </div>
                            <div class="causes-one__content">
                                <h3 class="causes-one__title"><a href="https://rooffederation.com/child-friendly-spaces">Child Education</a>
                                </h3>
                                <p class="causes-one__text">Time may wait for you and me, but not for our children. Therefore, right education with right opportunities at the right time is the focus of this project. We don’t let any child easily drop out.</p> 
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms" onclick="location.href='https://rooffederation.com/tree-plantation'">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="https://rooffederation.com/uploads/shutterstock_417312760.jpg" alt="">
                                <div class="causes-one__cat">
                                    <p>Tree Plantation</p>
                                </div>
                            </div>
                            <div class="causes-one__content">
                                <h3 class="causes-one__title"><a href="https://rooffederation.com/tree-plantation/">Tree Plantation</a>
                                </h3>
                                <p class="causes-one__text">Trees have uncountable benefits for humans to cherish. These include the release of oxygen into the air, absorption of unpleasant odour as well as harmful gases such as carbon dioxide, carbon monoxide and sulfur dioxide from the air and its purification.</p>
                                 
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms" onclick="location.href='https://rooffederation.com/child-sponsor'">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="https://rooffederation.com/uploads/hunger.jpeg" alt="">
                                <div class="causes-one__cat">
                                    <p>Hunger Care</p>
                                </div>
                            </div>
                            <div class="causes-one__content">
                                <h3 class="causes-one__title"><a href="https://rooffederation.com/child-sponsor">Hunger Support</a>
                                </h3>
                                <p class="causes-one__text">Hunger is a global issue that affects millions of people every day. At Roof Federation, we believe that no one should go hungry. That’s why we’re dedicated to fighting hunger and providing food assistance to those in need.</p>
                                 
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                </div>
                
                <div class="row">
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms" onclick="location.href='https://rooffederation.com/women-empowerment'">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="https://rooffederation.com/wmen.jpeg" alt="">
                                <div class="causes-one__cat">
                                    <p>Empowerment</p>
                                </div>
                            </div>
                            <div class="causes-one__content">
                                <h3 class="causes-one__title"><a href="https://rooffederation.com/women-empowerment">Women Empowerment</a>
                                </h3>
                                <p class="causes-one__text">Women's empowerment can be defined to promoting women's sense of self-worth, their ability to determine their own choices, and their right to influence social change for themselves and others.</p> 
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms" onclick="location.href='https://rooffederation.com/old-age-people'">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="https://rooffederation.com/uploads/olddage.jpeg" alt="">
                                <div class="causes-one__cat">
                                    <p>Old Age Peoples</p>
                                </div>
                            </div>
                            <div class="causes-one__content sw">
                                <h3 class="causes-one__title"><a href="https://rooffederation.com/old-age-people">Homes for Old Age Peoples</a>
                                </h3>
                                <p class="causes-one__text">One of the most famous and loved elderly homes and to feel the like environment then contact us today. We are committed to providing you with an excellent Elderly Care Old Age Home in Delhi to make your stay memorable and find everything you need. Here you will get excellent amenities and facilities at a very affordable cost.</p>
                                 
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms" onclick="location.href='https://rooffederation.com/blood-donation'">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="https://rooffederation.com/uploads/blooddec.jpeg" alt="">
                                <div class="causes-one__cat">
                                    <p>Blood Donate</p>
                                </div>
                            </div>
                            <div class="causes-one__content">
                                <h3 class="causes-one__title"><a href="https://rooffederation.com/blood-donation">Medical Care & Blood Donation</a>
                                </h3>
                                <p class="causes-one__text">We appreciate for your initiative for this noble cause and we are always here to help. Blood Donors are real hero as they are helping to save human life. Donating blood is a simple thing to do, but it can make a big difference in the lives.</p>
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                </div>
            </div>
        </section>
        <!--Causes One End-->


        <section class="feature-one sghdq">
            <div class="container">
                <div class="section-title text-center"> 
                    <h2 class="section-title__title">Become a Family of Roof Federation</h2>
                </div>
                <div class="row">
                    <div class="col-xl-4 col-lg-4  wow slideInLeft animated" data-wow-delay="100ms" data-wow-duration="2500ms" style="visibility: visible; animation-duration: 2500ms; animation-delay: 100ms; animation-name: slideInLeft;">
                        <div class="feature-one__single"> 
                            <div class="feature-one__top">
                                <div class="feature-one__top-inner">
                                     
                                    <div class="feature-one__top-title-box">
                                        <h3 class="feature-one__top-title"><a href="https://rooffederation.com/donate/?amt=9999">Education Support For Children</a></h3>
                                    </div>
                                </div>
                            </div>
                            <p class="feature-one__text">Better education equals a better nation. Be educated and feel empowered. Education makes the world a better place</p>
                            <ul class="list-unstyled feature-one__point">
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Here We Provide Free Books</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>A Nutritional Meal For Childrens</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Toys And Emotional Support</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Step By Step Consulting Every Child</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Group Community Gathering</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Perks For The Member</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Get A Recyclable Merchant From Roof Federation</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Latest Invitation For Every New Event</p>
                                    </div>
                                </li>
                                 
                            </ul> 
                             <div class="text-center">
                            <a href="https://rooffederation.com/donate/?amt=9999" class="thm-btn feature-one__btn">Get Membership</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4  wow slideInLeft animated" data-wow-delay="100ms" data-wow-duration="2500ms" style="visibility: visible; animation-duration: 2500ms; animation-delay: 100ms; animation-name: slideInLeft;">
                        <div class="feature-one__single"> 
                            <div class="feature-one__top">
                                <div class="feature-one__top-inner">
                                     
                                    <div class="feature-one__top-title-box">
                                        <h3 class="feature-one__top-title"><a href="https://rooffederation.com/donate/?amt=24999">Help And Support For Women Empowerment</a></h3>
                                    </div>
                                </div>
                            </div>
                            <p class="feature-one__text">Women's empowerment equips and allows women to make life-determining decisions through the different societal problems. They may have the opportunity to re-define gender roles or other such roles, which allow them more freedom to pursue</p>
                            <ul class="list-unstyled feature-one__point">
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Taking Session With Women Regularly And Their Problems</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p> Identifying Their Problems And Analysing What We Can For That</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Placing Them To A Job So They Can Do Anything</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Motivating Them</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Providing Essential Thing</p>
                                    </div>
                                </li>
                                
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Giving Knowledge So That Aware With Harrasment Kind Of Things </p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Telling Their Rights That Given By The Constitution</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Perks For The Members </p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Get Recyclable Merch From Roof Federation </p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Face To Face Conversation With Women's </p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Get Every Month Analasis Report Of Their Condition </p>
                                    </div>
                                </li>
                                 
                                 
                                 <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Latest Invitation For Every New Event </p>
                                    </div>
                                </li>
                                 
                                 
                            </ul> 
                            <div class="text-center">
                            <a href="https://rooffederation.com/donate/?amt=24999" class="thm-btn feature-one__btn">Get Membership</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4  wow slideInLeft animated" data-wow-delay="100ms" data-wow-duration="2500ms" style="visibility: visible; animation-duration: 2500ms; animation-delay: 100ms; animation-name: slideInLeft;">
                        <div class="feature-one__single"> 
                            <div class="feature-one__top">
                                <div class="feature-one__top-inner">
                                     
                                    <div class="feature-one__top-title-box">
                                        <h3 class="feature-one__top-title"><a href="https://rooffederation.com/donate/?amt=4999">Fight Against Hunger</a></h3>
                                    </div>
                                </div>
                            </div>
                            <p class="feature-one__text">It is a well-known fact that there are enough resources and wealth to eradicate hunger if distributed with justice and through charity.</p>
                            <ul class="list-unstyled feature-one__point">
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Feeding Hungry Children</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Giving Them Nutritious Food </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Donating Blanket And Pillow So They Take Sleep</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Placing Them Into The Shelters </p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Providing Essential Thing</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p> Perks For The Members</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Get Recyclable Merch From Roof Federation</p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Get A Private Number To Contect With Roof Federation </p>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Latest Invitation For Every New Event</p>
                                    </div>
                                </li>
                                 

                            </ul> 
                            <div class="text-center">
                            <a href="https://rooffederation.com/donate/?amt=4999" class="thm-btn feature-one__btn">Get Membership</a>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        
        
        
        <!--Become Volunteer One Start-->
        <section class="become-volunteer-one">
            <div class="become-volunteer-one__bg-box">
                <div class="become-volunteer-one__bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                    style="background-image: url(https://rooffederation.com/uploads/bnhs.jpeg);"></div>
            </div>
            <div class="become-volunteer-one__shape-1"
                style="background-image: url(assets/images/shapes/become-volunteer-shape-1.png);"></div>
            <div class="container">
                <div class="become-volunteer-one__inner">
                    <p class="become-volunteer-one__sub-title">Let’s Join our hands together</p>
                    <h3 class="become-volunteer-one__title">Har safar par! Har dagar par! Hum hai apke Humsafar
                    </h3>
                    <div class="become-volunteer-one__btn-box">
                        <a href="https://rooffederation.com/become-a-volunteer/" class="thm-btn become-volunteer-one__btn">Get Involved Now</a>
                    </div>
                </div>
            </div>
        </section>
        <!--Become Volunteer One End-->

         

        
       <section class="feature-one">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12  wow slideInLeft animated" data-wow-delay="100ms" data-wow-duration="2500ms" style="visibility: visible; animation-duration: 2500ms; animation-delay: 100ms; animation-name: slideInLeft;">
                        <div class="feature-one__single">
                            <div class="feature-one__single-bg" style="background-image: url(https://rooffederation.com/assets/images/shapes/feature-one-shape-1.png);"></div>
                            <div class="feature-one__top">
                                <div class="feature-one__top-inner">
                                    <div class="feature-one__top-icon">
                                        <span class="icon-help"></span>
                                    </div>
                                    <div class="feature-one__top-title-box">
                                        <h3 class="feature-one__top-title"><a href="">Objective of the trust</a></h3>
                                    </div>
                                </div>
                            </div>
                             
                            <ul class="list-unstyled feature-one__point">
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>To Educate and spread awareness among the citizen of India especially weaker section of the society. </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>The Trust will work to promote Health / Medical / Literacy / Education / Awareness and social activities.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Environment Protection, Pollution Control, Tree Plantation.</p>
                                    </div>
                                </li>
                                
                                
                                
                                
                                
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>To Open, manage, and run institute, school, and colleges etc.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>To work for Moral education and encourage the children in the field of education & sports and their rights, duties, and work for eradication of social evils like dowry, bribery, smoking, drug addiction & adulteration etc.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>To organize social events and medical treatment/check-up camps for the people and help the poor ailing persons by providing medical aid/medicines etc and, Blindness, Cancer Patients help.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>To look after aged persons in old age homes/shelters and help the widows.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>To run libraries, reading room, dispensary, hospital, training institutions for computer, fine arts, painting, yoga etc.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Women & Youth Empowerment, Skill Development, Digital INDIA & START Ups Awareness.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>We are helping people by providing Food, Education Medicines, Clothes and our future Goals are to give them a Roof for living.</p>
                                    </div>
                                </li> 
                            </ul> 
                        </div>
                    </div> 
                </div>
            </div>
        </section>
 
 
 <!--Become Volunteer Page Start-->
        <section class="become-volunteer-page pdtp0q">
            <div class="container">
                <div class="section-title text-center">
                    <span class="section-title__tagline">Register yourself with us</span>
                    <h2 class="section-title__title">Let’s join our community to <br> become a volunteer</h2>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-lg-6">
                        <div class="become-volunteer-page__left">
                             
                            <div class="become-volunteer-page__content">
                                <h3 class="become-volunteer-page__title">Requirements</h3>
                                <p class="become-volunteer-page__text">Becoming a volunteer content creator can be a rewarding way to share your knowledge, skills, and passions with others. Here are some steps you can take to become a volunteer content creator:</p>
                                <ul class="list-unstyled become-volunteer__points">
                                    <li>
                                        <div class="icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="text">
                                            <p>Look for organizations or platforms that align with your areas of expertise and values.</p>
                                        </div>
                                    </li>
                                    <br>
                                    <li>
                                        <div class="icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <div class="text">
                                            <p> Once you have been accepted as a volunteer content creator, start creating content! This could include writing blog posts, creating videos, designing infographics, or any other type of content that aligns with the organization's goals and needs. Make sure to follow any guidelines or instructions provided by the organization, and be</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="become-volunteer__call">
                                <div class="become-volunteer__call-icon">
                                    <span class="icon-chat"></span>
                                </div>
                                <div class="become-volunteer__call-content">
                                    <span>Call Anytime</span>
                                    <p><a href="tel:+91-8448317369">+91-8448317369</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="become-volunteer-page__right">
                            <form class="become-volunteer-page__form">
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="become-volunteer-page__input">
                                            <input type="text" placeholder="Your Name" name="name">
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="become-volunteer-page__input">
                                            <input type="email" placeholder="Email Address" name="email">
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="become-volunteer-page__input">
                                            <input type="text" placeholder="Phone Number" name="phone">
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="become-volunteer-page__input">
                                            <input type="text" placeholder="Address" name="Address">
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="become-volunteer-page__input">
                                            <input type="text" placeholder="Date of Birth" name="date" id="datepicker">
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="become-volunteer-page__input">
                                            <input type="text" placeholder="Occupation" name="Occupation">
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="become-volunteer-page__input become-volunteer__message-box">
                                            <textarea name="message" placeholder="Write a Comment"></textarea>
                                        </div>
                                        <div class="become-volunteer-page__btn-box">
                                            <button type="submit" class="thm-btn become-volunteer-page__btn">Send a
                                                message</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Become Volunteer Page End-->
        
 
         
         <!--<div class='sk-instagram-feed' data-embed-id='143000'></div><script src='https://widgets.sociablekit.com/instagram-feed/widget.js' async defer></script>-->
         <div class="embedsocial-hashtag" data-ref="89d74b7e61e112e0e0e3221981ef3585b3abbf51"> <a class="feed-powered-by-es feed-powered-by-es-feed-new" href="https://embedsocial.com/social-media-aggregator/" target="_blank" title="Widget by EmbedSocial"> Widget by EmbedSocial<span>→</span> </a> </div> <script> (function(d, s, id) { var js; if (d.getElementById(id)) {return;} js = d.createElement(s); js.id = id; js.src = "https://embedsocial.com/cdn/ht.js"; d.getElementsByTagName("head")[0].appendChild(js); }(document, "script", "EmbedSocialHashtagScript")); </script>
         
<?php include "footer.php"; ?>