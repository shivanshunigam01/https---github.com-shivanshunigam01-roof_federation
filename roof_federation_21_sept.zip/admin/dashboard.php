<?php include 'header.php';
 

?>	
<div class="right_col" role="main">       
 <div class="">         
 <div class="page-title">          
 <div class="title_left">          
 <h3>Admin : Dashboard</h3>          
 </div>        
 </div>		
 <div class="clearfix"></div>	
 <div class="row">            
 <div class="col-md-12 col-sm-12 col-xs-12">	
 <div class="row tile_count">        
 <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">      
 <span class="count_top"><i class="fa fa-list" ></i> Contacts</span>     
 <div class="count"><?php echo $total_consumer; ?></div>                   
 </div> 
 
 </div>	
 
 </div>			
 </div>		
 </div>       
 </div>        	
 <?php include 'footer.php'; ?>