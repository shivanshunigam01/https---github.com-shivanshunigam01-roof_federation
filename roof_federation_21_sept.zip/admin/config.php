<?php  
date_default_timezone_set("Asia/Calcutta");
include "NotORM.php";
$dsn = "mysql:dbname=u304337141_ngo;host=localhost";
$pdo = new PDO($dsn, "u304337141_ngo", "Shanal@16");
$db = new NotORM($pdo); 
?>